create view v_price_with_discount(name, pizza_name, price, discount_price) as
SELECT p.name,
       m.pizza_name,
       m.price,
       m.price - m.price * 0.1 AS discount_price
FROM person_order
         JOIN menu m ON m.id = person_order.menu_id
         JOIN person p ON p.id = person_order.person_id
ORDER BY p.name, m.pizza_name;

alter table v_price_with_discount
    owner to postgres;

